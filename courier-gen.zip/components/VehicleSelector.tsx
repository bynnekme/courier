
import React from 'react';
import { VEHICLES } from '../constants';
import type { Vehicle } from '../types';

interface VehicleSelectorProps {
  selectedId: string | null;
  onSelect: (id: string) => void;
}

const VehicleSelector: React.FC<VehicleSelectorProps> = ({ selectedId, onSelect }) => {
  return (
    <div className="flex space-x-4">
      {VEHICLES.map((vehicle: Vehicle) => (
        <button
          key={vehicle.id}
          onClick={() => onSelect(vehicle.id)}
          className={`flex-1 p-4 rounded-lg border-2 text-center transition-all duration-200 ${
            selectedId === vehicle.id
              ? 'bg-blue-600 text-white border-blue-600 shadow-lg'
              : 'bg-slate-700 text-slate-200 hover:bg-slate-600 border-slate-600 hover:border-blue-500'
          }`}
        >
          <span className="text-3xl" role="img" aria-label={vehicle.name}>{vehicle.icon}</span>
          <p className="mt-2 font-semibold text-sm">{vehicle.name}</p>
        </button>
      ))}
    </div>
  );
};

export default VehicleSelector;