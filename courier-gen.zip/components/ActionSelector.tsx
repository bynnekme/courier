
import React from 'react';
import { ACTIONS } from '../constants';
import type { Action } from '../types';

interface ActionSelectorProps {
  selectedId: string | null;
  onSelect: (id: string) => void;
}

const ActionSelector: React.FC<ActionSelectorProps> = ({ selectedId, onSelect }) => {
  return (
    <div className="flex flex-col space-y-3">
      {ACTIONS.map((action: Action) => (
        <button
          key={action.id}
          onClick={() => onSelect(action.id)}
          className={`w-full p-3 rounded-lg border-2 text-left transition-all duration-200 ${
            selectedId === action.id
              ? 'bg-blue-600 text-white border-blue-600 shadow-lg'
              : 'bg-slate-700 text-slate-200 hover:bg-slate-600 border-slate-600 hover:border-blue-500'
          }`}
        >
          {action.name}
        </button>
      ))}
    </div>
  );
};

export default ActionSelector;