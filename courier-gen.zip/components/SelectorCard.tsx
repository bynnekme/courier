
import React from 'react';

interface SelectorCardProps {
  step: number;
  title: string;
  children: React.ReactNode;
}

const SelectorCard: React.FC<SelectorCardProps> = ({ step, title, children }) => {
  return (
    <div className="bg-slate-800 p-6 rounded-lg shadow-lg mb-6">
      <h3 className="text-xl font-semibold text-slate-200 mb-4">
        <span className="bg-blue-600 text-white rounded-full w-8 h-8 inline-flex items-center justify-center mr-3 text-base">{step}</span>
        {title}
      </h3>
      {children}
    </div>
  );
};

export default SelectorCard;