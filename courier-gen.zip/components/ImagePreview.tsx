
import React from 'react';

interface ImagePreviewProps {
  imageUrl: string | null;
  isLoading: boolean;
  error: string | null;
  formatId: string | null;
}

const LoadingSpinner: React.FC = () => (
    <div className="flex flex-col items-center justify-center text-center">
        <svg className="animate-spin -ml-1 mr-3 h-10 w-10 text-blue-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
        <p className="mt-4 text-slate-300 font-semibold">Generating your image...</p>
        <p className="mt-2 text-slate-400 text-sm">This may take a moment. Please wait.</p>
    </div>
);

const Placeholder: React.FC = () => (
    <div className="flex flex-col items-center justify-center text-center text-slate-500">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-slate-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1">
            <path strokeLinecap="round" strokeLinejoin="round" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
        </svg>
        <p className="mt-4 font-semibold">Your generated image will appear here</p>
        <p className="mt-1 text-sm">Complete all the steps on the left to start.</p>
    </div>
);


const ImagePreview: React.FC<ImagePreviewProps> = ({ imageUrl, isLoading, error, formatId }) => {
  const handleDownload = () => {
    if (!imageUrl) return;
    const link = document.createElement('a');
    link.href = imageUrl;
    link.download = `courier-gen-${Date.now()}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getAspectRatioClass = () => {
    switch (formatId) {
        case 'vertical':
            return 'aspect-[9/16]';
        case 'horizontal':
            return 'aspect-[16/9]';
        case 'square':
        default:
            return 'aspect-square';
    }
  }
    
  return (
    <div className="h-full flex flex-col">
      <div className={`w-full bg-slate-700 rounded-lg flex items-center justify-center transition-all duration-300 ${getAspectRatioClass()}`}>
        {isLoading && <LoadingSpinner />}
        {!isLoading && !imageUrl && !error && <Placeholder />}
        {!isLoading && imageUrl && (
          <img src={imageUrl} alt="Generated courier" className="object-contain w-full h-full rounded-md" />
        )}
        {!isLoading && error && (
            <div className="text-center text-red-500 p-4">
                <p className="font-bold">Generation Failed</p>
                <p className="text-sm mt-2">{error}</p>
            </div>
        )}
      </div>
      {imageUrl && !isLoading && (
        <button
          onClick={handleDownload}
          className="mt-4 w-full bg-green-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-green-700 transition-colors duration-200 flex items-center justify-center"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM6.293 9.707a1 1 0 011.414 0L9 11.086V3a1 1 0 112 0v8.086l1.293-1.379a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" />
          </svg>
          Download Image
        </button>
      )}
    </div>
  );
};

export default ImagePreview;