
import React from 'react';
import { ENVIRONMENTS } from '../constants';
import type { Environment } from '../types';

interface EnvironmentSelectorProps {
  selectedId: string | null;
  onSelect: (id: string) => void;
}

const EnvironmentSelector: React.FC<EnvironmentSelectorProps> = ({ selectedId, onSelect }) => {
  return (
    <select
      value={selectedId || ''}
      onChange={(e) => onSelect(e.target.value)}
      className="w-full p-3 border border-slate-600 rounded-lg bg-slate-700 text-slate-200 focus:ring-2 focus:ring-blue-500 focus:outline-none focus:bg-slate-600"
    >
      <option value="" disabled>Select an environment...</option>
      {ENVIRONMENTS.map((env: Environment) => (
        <option key={env.id} value={env.id}>
          {env.displayName}
        </option>
      ))}
    </select>
  );
};

export default EnvironmentSelector;