
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-slate-800 shadow-lg">
      <div className="container mx-auto px-6 py-4">
        <h1 className="text-3xl font-bold text-white">Courier-Gen</h1>
        <p className="text-slate-300 mt-1">AI-Powered Image Generation for Food Delivery Recruitment</p>
      </div>
    </header>
  );
};

export default Header;