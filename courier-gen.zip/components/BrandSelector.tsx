
import React from 'react';
import { BRANDS } from '../constants';
import type { Brand } from '../types';

interface BrandSelectorProps {
  selectedId: string | null;
  onSelect: (id: string) => void;
}

const BrandSelector: React.FC<BrandSelectorProps> = ({ selectedId, onSelect }) => {
  return (
    <select
      value={selectedId || ''}
      onChange={(e) => onSelect(e.target.value)}
      className="w-full p-3 border border-slate-600 rounded-lg bg-slate-700 text-slate-200 focus:ring-2 focus:ring-blue-500 focus:outline-none focus:bg-slate-600"
    >
      <option value="" disabled>Select a brand...</option>
      {BRANDS.map((brand: Brand) => (
        <option key={brand.id} value={brand.id}>
          {brand.name}
        </option>
      ))}
    </select>
  );
};

export default BrandSelector;