
import React from 'react';
import { CHARACTERS } from '../constants';
import type { Character } from '../types';

interface CharacterSelectorProps {
  selectedId: string | null;
  onSelect: (id: string) => void;
}

const CharacterSelector: React.FC<CharacterSelectorProps> = ({ selectedId, onSelect }) => {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
      {CHARACTERS.map((char: Character) => (
        <div
          key={char.id}
          onClick={() => onSelect(char.id)}
          className={`cursor-pointer rounded-lg overflow-hidden border-2 transition-all duration-200 ${
            selectedId === char.id ? 'border-blue-500 ring-2 ring-blue-500' : 'border-transparent hover:border-blue-400'
          }`}
        >
          <img src={char.imageUrl} alt={char.name} className="w-full h-auto object-cover aspect-square" />
          <p className="text-center bg-slate-700 p-2 text-sm font-medium text-slate-200">{char.name}</p>
        </div>
      ))}
    </div>
  );
};

export default CharacterSelector;