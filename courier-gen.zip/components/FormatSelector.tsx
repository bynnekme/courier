
import React from 'react';
import { FORMATS } from '../constants';
import type { Format } from '../types';

interface FormatSelectorProps {
  selectedId: string | null;
  onSelect: (id: string) => void;
}

const FormatCard: React.FC<{ format: Format; isSelected: boolean; onSelect: () => void; }> = ({ format, isSelected, onSelect }) => {
    const aspectRatioClasses = {
        '9:16': 'aspect-[9/16] w-8',
        '1:1': 'aspect-square w-12',
        '16:9': 'aspect-[16/9] w-14',
    };
    
    return (
        <div
            onClick={onSelect}
            className={`cursor-pointer rounded-lg p-4 border-2 transition-all duration-200 flex flex-col items-center text-center ${
                isSelected 
                ? 'border-blue-500 ring-2 ring-blue-500 bg-slate-700' 
                : 'border-slate-600 hover:border-blue-400 bg-slate-700 hover:bg-slate-600'
            }`}
        >
            <div className="h-16 flex items-center justify-center mb-3">
                 <div className={`${aspectRatioClasses[format.aspectRatio]} bg-slate-500 rounded-sm`}></div>
            </div>
            <p className="font-semibold text-slate-200">{format.name}</p>
            <p className="text-xs text-slate-400">{format.dimensions}</p>
            <p className="text-xs text-slate-400 mt-1">{format.useCase}</p>
        </div>
    );
};


const FormatSelector: React.FC<FormatSelectorProps> = ({ selectedId, onSelect }) => {
  return (
    <div className="grid grid-cols-3 gap-4">
      {FORMATS.map((format: Format) => (
        <FormatCard
          key={format.id}
          format={format}
          isSelected={selectedId === format.id}
          onSelect={() => onSelect(format.id)}
        />
      ))}
    </div>
  );
};

export default FormatSelector;