
import type { Character, Vehicle, Brand, Environment, Action, Format } from './types';

export const CHARACTERS: Character[] = [
  { id: 'char_01', name: 'Ava', description: 'A smiling young woman in her early 20s with her hair in a ponytail, of Southeast Asian descent', imageUrl: 'https://picsum.photos/seed/char01/200/200' },
  { id: 'char_02', name: 'Ben', description: 'A cheerful man in his late 20s with short-cropped hair and a light beard, of Caucasian descent', imageUrl: 'https://picsum.photos/seed/char02/200/200' },
  { id: 'char_03', name: 'Chloe', description: 'A confident woman in her mid-20s with curly black hair, of Afro-Caribbean descent', imageUrl: 'https://picsum.photos/seed/char03/200/200' },
  { id: 'char_04', name: 'David', description: 'A friendly man in his early 30s with glasses and tidy brown hair, of Hispanic descent', imageUrl: 'https://picsum.photos/seed/char04/200/200' },
  { id: 'char_05', name: 'Emily', description: 'A student in her late teens with long blonde hair, of Northern European descent', imageUrl: 'https://picsum.photos/seed/char05/200/200' },
  { id: 'char_06', name: 'Frank', description: 'A reliable-looking man in his 40s with salt-and-pepper hair, of Middle Eastern descent', imageUrl: 'https://picsum.photos/seed/char06/200/200' },
];

export const VEHICLES: Vehicle[] = [
  { id: 'e-bike', name: 'E-Bike', icon: '🚲' },
  { id: 'moped', name: 'Moped', icon: '🛵' },
  { id: 'car', name: 'Car', icon: '🚗' },
];

export const BRANDS: Brand[] = [
  { 
    id: 'just_eat_uk', 
    name: 'Just Eat (UK)', 
    uniformDescription: 'a vibrant orange waterproof jacket with a white Just Eat logo on the chest and back',
    equipmentDescription: 'a large, cube-shaped vibrant orange thermal food delivery bag with the Just Eat logo'
  },
  { 
    id: 'lieferando_de', 
    name: 'Lieferando (Germany)', 
    uniformDescription: 'a bright orange jacket with the white Lieferando.de logo on it',
    equipmentDescription: 'a bright orange thermal backpack for food delivery with the Lieferando.de logo'
  },
  { 
    id: 'unbranded', 
    name: 'Unbranded', 
    uniformDescription: 'a plain, dark-colored waterproof jacket',
    equipmentDescription: 'a generic, non-branded thermal delivery bag'
  },
];

export const ENVIRONMENTS: Environment[] = [
  { id: 'london', name: 'a charming street in London with brick townhouses', displayName: 'London' },
  { id: 'berlin', name: 'a modern, bustling street in Berlin with contemporary architecture', displayName: 'Berlin' },
  { id: 'suburban', name: 'a generic, sunny suburban street with houses', displayName: 'Suburban' },
];

export const ACTIONS: Action[] = [
  { id: 'riding', name: 'Riding vehicle', description: 'confidently riding their vehicle down the street with a slight motion blur in the background' },
  { id: 'delivering', name: 'Delivering to door', description: 'smiling as they hand a food bag to a customer at a modern front door' },
  { id: 'checking_phone', name: 'Checking phone', description: 'paused on their vehicle, looking at a map on their smartphone which is mounted on the handlebars' },
];

export const FORMATS: Format[] = [
    { id: 'vertical', name: 'Vertical', aspectRatio: '9:16', dimensions: '1080x1920px', useCase: 'Stories, Reels, TikTok' },
    { id: 'square', name: 'Square', aspectRatio: '1:1', dimensions: '1080x1080px', useCase: 'Feed Posts, Carousels' },
    { id: 'horizontal', name: 'Horizontal', aspectRatio: '16:9', dimensions: '1920x1080px', useCase: 'Display Ads, YouTube' },
];