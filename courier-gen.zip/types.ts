
export interface Character {
  id: string;
  name: string;
  description: string;
  imageUrl: string;
}

export interface Vehicle {
  id: string;
  name: string;
  icon: string;
}

export interface Brand {
  id: string;
  name: string;
  uniformDescription: string;
  equipmentDescription: string;
}

export interface Environment {
  id: string;
  name: string;
  displayName: string;
}

export interface Action {
  id: string;
  name: string;
  description: string;
}

export interface Format {
  id: 'vertical' | 'square' | 'horizontal';
  name: string;
  aspectRatio: '9:16' | '1:1' | '16:9';
  dimensions: string;
  useCase: string;
}

export interface Selections {
  formatId: string | null;
  characterId: string | null;
  vehicleId: string | null;
  brandId: string | null;
  environmentId: string | null;
  actionId: string | null;
}