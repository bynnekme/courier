
import React, { useState, useMemo } from 'react';
import type { Selections } from './types';
import Header from './components/Header';
import SelectorCard from './components/SelectorCard';
import CharacterSelector from './components/CharacterSelector';
import VehicleSelector from './components/VehicleSelector';
import BrandSelector from './components/BrandSelector';
import EnvironmentSelector from './components/EnvironmentSelector';
import ActionSelector from './components/ActionSelector';
import ImagePreview from './components/ImagePreview';
import FormatSelector from './components/FormatSelector';
import { generateCourierImage } from './services/geminiService';

const App: React.FC = () => {
  const [selections, setSelections] = useState<Selections>({
    formatId: 'square',
    characterId: null,
    vehicleId: null,
    brandId: null,
    environmentId: null,
    actionId: null,
  });

  const [generatedImageUrl, setGeneratedImageUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const isGenerationDisabled = useMemo(() => {
    return Object.values(selections).some(value => value === null);
  }, [selections]);

  const handleSelection = <K extends keyof Selections,>(key: K, value: Selections[K]) => {
    setSelections(prev => ({ ...prev, [key]: value }));
  };

  const handleGenerateClick = async () => {
    if (isGenerationDisabled) return;
    setIsLoading(true);
    setGeneratedImageUrl(null);
    setError(null);
    try {
      const imageUrl = await generateCourierImage(selections);
      setGeneratedImageUrl(imageUrl);
    } catch (err) {
        if (err instanceof Error) {
            setError(err.message);
        } else {
            setError("An unknown error occurred.");
        }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen">
      <Header />
      <main className="container mx-auto p-4 sm:p-6 lg:p-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Left Column: Selectors */}
          <div>
            <SelectorCard step={1} title="Select a Format">
              <FormatSelector 
                selectedId={selections.formatId}
                onSelect={(id) => handleSelection('formatId', id)}
              />
            </SelectorCard>
            <SelectorCard step={2} title="Choose a Character">
              <CharacterSelector
                selectedId={selections.characterId}
                onSelect={(id) => handleSelection('characterId', id)}
              />
            </SelectorCard>
            <SelectorCard step={3} title="Select a Vehicle">
              <VehicleSelector
                selectedId={selections.vehicleId}
                onSelect={(id) => handleSelection('vehicleId', id)}
              />
            </SelectorCard>
            <SelectorCard step={4} title="Select a Brand">
              <BrandSelector
                selectedId={selections.brandId}
                onSelect={(id) => handleSelection('brandId', id)}
              />
            </SelectorCard>
            <SelectorCard step={5} title="Select an Environment">
              <EnvironmentSelector
                selectedId={selections.environmentId}
                onSelect={(id) => handleSelection('environmentId', id)}
              />
            </SelectorCard>
            <SelectorCard step={6} title="Select an Action">
              <ActionSelector
                selectedId={selections.actionId}
                onSelect={(id) => handleSelection('actionId', id)}
              />
            </SelectorCard>
          </div>

          {/* Right Column: Preview and Generation */}
          <div className="sticky top-8 self-start">
            <div className="bg-slate-800 p-6 rounded-lg shadow-lg">
                <h3 className="text-xl font-semibold text-slate-200 mb-4">
                    Image Preview
                </h3>
                 <ImagePreview
                    imageUrl={generatedImageUrl}
                    isLoading={isLoading}
                    error={error}
                    formatId={selections.formatId}
                />
                <button
                    onClick={handleGenerateClick}
                    disabled={isGenerationDisabled || isLoading}
                    className="mt-6 w-full bg-blue-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-blue-700 transition-colors duration-200 disabled:bg-slate-600 disabled:cursor-not-allowed flex items-center justify-center"
                >
                    {isLoading ? (
                        <>
                            <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            Generating...
                        </>
                    ) : 'Generate Image'}
                </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;